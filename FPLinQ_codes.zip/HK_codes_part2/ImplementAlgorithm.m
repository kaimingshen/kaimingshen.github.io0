function [ avg_rate ] = ImplementAlgorithm( L, K, NOISE, M, N, G, H, Xmax, association, alg, seed, nIter, index )

% global w
global nSlots

avg_rate = zeros(K,1);
w = ones(K,1);%*1e3; % initial weight
alpha = 0.99; % exponential factor for updating rate

nIter = 50;

init_V = nan(M,K,N);
for i = 1:K
    for s = 1:N
        init_V(:,i,s) = ones(M,1)*sqrt(Xmax(i)/M);
    end
end  

for t = 1:nSlots
    schedule = Scheduler(L, K, N, NOISE, G, Xmax, association, w);
    V = init_V;
    switch alg
        case 'Power'
            [V, U] = RunAlgWMMSEbeamforming(L, K, M, N, NOISE, H, Xmax, schedule, V, w, nIter);
        case 'Proposed'
            [ schedule, V, U ] = RunAlgProposed(L, K, M, N, NOISE, H, Xmax, schedule, V, w, nIter);
        case 'WMMSE'
            [ schedule, V, U ] = RunAlgWMMSE( L, K, M, N, NOISE, H, Xmax, schedule, w, nIter);
        case 'Old'
            [ schedule, V, U ] = AlgProposedOld(L, K, M, N, NOISE, H, Xmax, schedule, V, w, nIter);
        otherwise
            error('Unknown Algorithm!')
    end
    
    fprintf('%d-%d-%s: <slot %d>\n', index, seed, alg, t);
    ins_rate = ComputeRate(L, K, N, NOISE, H, schedule, V, U);
    avg_rate = avg_rate + ins_rate;
    w = 1./(alpha./w+(1-alpha)*ins_rate);
end

avg_rate = avg_rate/nSlots;

end

