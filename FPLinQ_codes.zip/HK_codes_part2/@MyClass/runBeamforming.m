function [ V ] = runBeamforming( obj, weight, schedule, V )

SINR = computeSINR(obj, schedule, V);
Y = updateY( obj, weight, schedule, V, SINR );
V = updateV( obj, weight, SINR, Y, schedule );

end

%%
function [ Y ] = updateY( obj, weight, schedule, V, SINR )

L = obj.numBS;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
Y = zeros(N,M,L);
noise = obj.noise;

for j = 1:L
    i = schedule(j);
    if i==0
        continue
    end
    A = sqrt(weight(i,j))*H(:,:,i,j)*V(:,:,i)*sqrtm(eye(M)+SINR(:,:,j));
    B = eye(N)*noise;
    for n = 1:L
        m = schedule(n);
        if m==0
            continue
        end
        B = B + H(:,:,m,j)*V(:,:,m)*V(:,:,m)'*H(:,:,m,j)';
    end
    Y(:,:,j) = B\A;
end

end

%%
function [ V ] = updateV( obj, weight, SINR, Y, schedule )

L = obj.numBS;
K = obj.numUser;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
maxPower = obj.maxPower;
noise = obj.noise;
V = zeros(M,M,K);
Z = nan(M,M,K,L);
       
for j=1:L
    i = schedule(j);
    if i>0
        B = zeros(M,M);
        for n = 1:L
            B = B + H(:,:,i,n)'*Y(:,:,n)*Y(:,:,n)'*H(:,:,i,n);
        end        
        A = sqrt(weight(i,j))*H(:,:,i,j)'*Y(:,:,j)*sqrtm(eye(M)+SINR(:,:,j));
        tempZ = B\A;
        
        if real(trace(tempZ*tempZ')) <= maxPower(i)
            V(:,:,i) = tempZ;
            continue
        end
        
        % bisection search on opt mu
        muLeft = 0;
        muRight = 1;
        while 1
            tempZ = (B+muRight*eye(M))\A;
            if real(trace(tempZ*tempZ')) <= maxPower(i)
                break
            end
            muRight = muRight*10;
        end
        
%         count = 0;
        while 1
            mu = (muLeft+muRight)/2;
            tempZ = (B+mu*eye(M))\A;
    
            if abs(trace(tempZ*tempZ')-maxPower(i)) < noise
                V(:,:,i) = tempZ;
                break
            end
            
%             count = count+1;
%             
%             if count>500
%                 V(:,:,i) = tempZ;
%                 break
%             end
            
            if trace(tempZ*tempZ') > maxPower(i)
                muLeft = mu;
            else
                muRight = mu;
            end
        end
    end
end
            
end