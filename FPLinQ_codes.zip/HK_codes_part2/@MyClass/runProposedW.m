function [ schedule, V ] = runProposedW( obj, weight, numIter )

K = obj.numUser;
M = obj.numTxAnte;
maxPower = obj.maxPower;
schedule = initScheduler(obj, weight);

% initialize V
V = nan(M,M,K);
for i = 1:K
    V(:,:,i) = ones(M,M,1)*sqrt(maxPower(i)/(M*M));
end

KM = nan(1,numIter+1);
KM(1) = sum(computeInstRate(obj, schedule, V));

SINR = computeSINR(obj, schedule, V);

for iter = 1:numIter
%     SINR = computeSINR(obj, schedule, V);
    Y = updateY( obj, weight, schedule, V, SINR );
    SINR = computeSINR(obj, schedule, V);
    
    L = obj.numBS;
    H = obj.chn;
    gamma = nan(M,M,L);
    for j = 1:L
        i = schedule(j);
        gamma(:,:,j) = inv(eye(M)-Y(:,:,j)'*H(:,:,i,j)*V(:,:,i)) - eye(M);
    end
    gamma = real(gamma);
    
	[ schedule, V ] = updateScheduleAndV( obj, weight, SINR, Y, schedule );
    
    KM(iter+1) = sum(computeInstRate(obj, schedule, V));
end

plot(KM)

end

%%
function [ Y ] = updateY( obj, weight, schedule, V, SINR )

L = obj.numBS;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
Y = zeros(N,M,L);
noise = obj.noise;

for j = 1:L
    i = schedule(j);
    if i==0
        continue
    end
    A = H(:,:,i,j)*V(:,:,i);
    B = eye(N)*noise;
    for n = 1:L
        m = schedule(n);
        if m==0
            continue
        end
        B = B + H(:,:,m,j)*V(:,:,m)*V(:,:,m)'*H(:,:,m,j)';
    end
    Y(:,:,j) = B\A;
end

end

%%
function [ schedule, V ] = updateScheduleAndV( obj, weight, SINR, Y, schedule )

L = obj.numBS;
K = obj.numUser;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
maxPower = obj.maxPower;
V = zeros(M,M,K);
Z = nan(M,M,K,L);

for i = 1:K
    B = zeros(M,M);
    for n = 1:L
        m = schedule(n);
        B = B + weight(m)*H(:,:,i,n)'*Y(:,:,n)*(eye(M)+SINR(:,:,n))*Y(:,:,n)'*H(:,:,i,n);
    end
    
    for j = 1:L
        A = weight(i)*H(:,:,i,j)'*Y(:,:,j)*(eye(M)+SINR(:,:,j));
        tempZ = B\A;
        
        if trace(tempZ*tempZ') <= maxPower(i)
            Z(:,:,i,j) = tempZ;
            continue
        end
        
        % bisection search on opt mu
        muLeft = 0;
        muRight = 1;
        while 1
            tempZ = (B+muRight*eye(M))\A;
            if trace(tempZ*tempZ') <= maxPower(i)
                break
            end
            muRight = muRight*10;
        end
        
        while 1
            mu = (muLeft+muRight)/2;
            tempZ = (B+mu*eye(M))\A;
            if abs(trace(tempZ*tempZ')-maxPower(i)) < maxPower(i)/1e5
                Z(:,:,i,j) = tempZ;
                break
            end
            
            if trace(tempZ*tempZ') > maxPower(i)
                muLeft = mu;
            else
                muRight = mu;
            end
        end
    end
end

for j = 1:L
    i = schedule(j);
    V(:,:,i) = Z(:,:,i,j);
end

return

% matching
utility = nan(K,L);
for j = 1:L
    for i = 1:K
        utility(i,j) = weight(i)*log(det(eye(M)+SINR(:,:,j))) - weight(i)*trace(SINR(:,:,j))...
                + trace(2*sqrt(weight(i))*real(Z(:,:,i,j)'*H(:,:,i,j)'*Y(:,:,j)*sqrtm(eye(M)+SINR(:,:,j))));
        for n = 1:L
            utility(i,j) = utility(i,j) - trace(Y(:,:,n)'*(eye(N)+H(:,:,i,n)*Z(:,:,i,j)*Z(:,:,i,j)'*H(:,:,i,n)')*Y(:,:,n));
        end
    end
end
     
schedule = Hungarian(utility);
for j = 1:L
    i = schedule(j);
    V(:,:,i) = Z(:,:,i,j);
end
            
end