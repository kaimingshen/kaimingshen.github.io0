function [ SINR ] = computeSINR(obj, schedule, V)

L = obj.numBS;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
noise = obj.noise;
SINR = zeros(M,M,L);

for j = 1:L
    i = schedule(j);
    if i==0
        continue
    end
    
    B = noise*eye(N);
    for n = 1:L
        m = schedule(n);
        if n==j || m==0
            continue
        end
        B = B + H(:,:,m,j)*V(:,:,m)*V(:,:,m)'*H(:,:,m,j)';
    end
    
    SINR(:,:,j) = V(:,:,i)'*H(:,:,i,j)'*(B\(H(:,:,i,j)*V(:,:,i)));
end

SINR = real(SINR);

end