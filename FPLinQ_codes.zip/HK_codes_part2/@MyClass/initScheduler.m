function [ schedule ] = initScheduler( obj, weight )

intend = obj.intend;
L = obj.numBS;
K = obj.numUser;
schedule = zeros(L,1);

weight_seq = reshape(weight,[K*L,1]);
[~,user_list] = sort(weight_seq,'descend');
for w = user_list'
    i = mod(w,K);
    if i==0
        i = K;
    end
    j = (w-i)/K+1;
    if sum(intend{i}==j)>0 && sum(schedule==i)==0 && schedule(j)==0
        schedule(j)=i;
    end
end

end

