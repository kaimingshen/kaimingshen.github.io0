classdef MyClass
    
    properties
        bandwidth
        avgRate
        chn % channel coefficient
        chnMagnitude
        maxPower
        numBS
        numUser
        numTxAnte
        numRxAnte
        numSlot
        noise
        algorithm
        intend
    end
    
    methods
        function obj = MyClass( bandwidth, numBS, numUser, noise, numSlot,...
                numTxAnte, numRxAnte, H, G, maxPower, algorithm, intend)
            obj.bandwidth = bandwidth;
            obj.numBS = numBS;
            obj.numUser = numUser;
            obj.noise = noise;
            obj.numSlot = numSlot;
            obj.numTxAnte = numTxAnte;
            obj.numRxAnte = numRxAnte;
            obj.chn = H;
            obj.chnMagnitude = G;
            obj.maxPower = maxPower;
            obj.algorithm = algorithm;
            obj.intend = intend;
        end
        
        [ schedule, U, V ] = runAlgorithm(obj, weight)
        [ numSchedule, avgRate ] = computeAvgRate(obj)
        currentRate = computeCurrentRate(obj, schedule, U, V)
        currentSINR = computeCurrentSINR(obj, schedule, U, V)
    end
    
end

