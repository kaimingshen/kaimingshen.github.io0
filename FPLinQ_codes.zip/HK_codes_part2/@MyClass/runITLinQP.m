function [ schedule, V ] = runITLinQP( obj, weight, numIter )

L = obj.numBS;
K = obj.numUser;
G = obj.chnMagnitude;
intend = obj.intend;
maxPower = obj.maxPower;
noise = obj.noise;
power = maxPower;
schedule = zeros(L,1);

eta = 0.9;
gamma = 0.1;

weight_seq = reshape(weight,[K*L,1]);
[~,user_list] = sort(weight_seq,'descend');
for w = user_list'
    i = mod(w,K);
    if i==0
        i = K;
    end
    j = (w-i)/K+1;
    
    if sum(intend{i}==j)==0 || sum(schedule==i)==1 || schedule(j)==1
        continue
    end
    
    if sum(schedule>0)==0 % no link scheduled yet
        schedule(j) = i;
        continue
    end    
    
    SNR = G(i,j)*power(i)/noise;
    flag = 1; % set to 0 if a conflict detected
    for n = 1:L
        m = schedule(n);
        if m==0
            continue
        end
        %
        INR = G(i,n)*power(i)/noise;
        B = inf;
        for y = 1:L
            x = schedule(y);
            if x==i || x==m || x==0
                continue
            end
            B_new = G(x,n)*power(x)/noise;
            if B_new < B
                B = B_new;
            end
        end
        if SNR^eta < INR/B^gamma
            flag = 0;
            break
        end
        %
        INR = G(m,j)*power(m)/noise;
        B = inf;
        for y = 1:L
            if y==j || y==n || schedule(y)==0
                continue
            end
            B_new = G(m,y)*power(m)/noise;
            if B_new < B
                B = B_new;
            end
        end
        if SNR^eta < INR/B^gamma
            flag = 0;
            break
        end
    end
    
    if flag==1
        schedule(j) = i;
    else
        power(i) = 0;
    end
end

V = runNewton( obj, weight, numIter, power, schedule );


% GG = squeeze(G);
% cvx_begin gp
%     variables power(L,1) t(L,1)
% %     maximize (  prod(t(scheduled_users)) )
%     maximize (  sum(weight(scheduled_users).*log(t(scheduled_users))) )
%     subject to
%         power >= zeros(L,1)
%         power <= maxPower'
%         for i = scheduled_users
%             GG(i,i)*power(i)>=t(i)*(GG(i,1:L~=i)*power(1:L~=i)+noise)%-GG(i,i)*power(i))
% %             power(i) >= 0
% %             power(i) <= maxPower(i)
%         end
% cvx_end
            
end