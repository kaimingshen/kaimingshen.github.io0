function [ avgRate ] = computeAvgRate( obj )

intend = obj.intend;
L = obj.numBS;
K = obj.numUser;

sumRate = zeros(K,L);
weight = ones(K,L)*1e3;
alpha = .9;

for t = 1:obj.numSlot
    fprintf('slot: %d ___ %s \n', t, obj.algorithm);
    [ schedule, V ] = runAlgorithm(obj, weight);
    [txRate, rxRate, rate] = computeInstRate(obj, schedule, V);
    sumRate = sumRate + rate;
    weight = 1 ./ (alpha./weight + (1-alpha)*rate);            
end
    
linkRate = sumRate/obj.numSlot;

avgRate = [];
for i = 1:K
    for j = intend{i}
        avgRate = [avgRate, linkRate(i,j)];
    end
end

end

