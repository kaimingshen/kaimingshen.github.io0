function [ schedule, U, V ] = runFixed( obj, weight, numIter )

L = obj.numBS;
K = obj.numUser;
M = obj.numTxAnte;
N = obj.numRxAnte;
noise = obj.noise;
H = obj.chn;
maxPower = obj.maxPower;
association = obj.association;
schedule = initScheduler(obj, weight);

% initialize
V = nan(M,K);
for i = 1:K
    V(:,i) = ones(M,1)*sqrt(maxPower(i)/M);
end

for iter = 1:numIter
    % beamforming
    [schedule, U, V ] = runBeamforming(obj, weight, schedule, V, 1);
    
    %%
    newSchedule = nan(L,N);
    for j = 1:L
        usersInCell = find(association==j)';
        numUsersInCell = length(usersInCell);
        
        utility = nan(numUsersInCell,N);
        for s = 1:N
            B = noise*norm(U(:,j,s))^2;
            for n = 1:L
                for t = 1:N
                    m = schedule(n,t);
                    if m == schedule(j,s)
                        continue
                    end
                    B = B + norm(U(:,j,s)'*H(:,:,m,j)*V(:,m))^2;
                end
            end
            
            for q = 1:numUsersInCell
                i = usersInCell(q);
                A = norm(U(:,j,s)'*H(:,:,i,j)*V(:,i))^2;
                utility(q,s) = weight(i)*log2(1+A/B);
            end
        end
        
        assignment = Hungarian(utility);
        for s = 1:N
            newSchedule(j,s) = usersInCell(assignment(s));
        end
    end
    schedule = newSchedule;
end
            
end

%     % adjust schedule
%     oldSchedule = schedule;
%     for j = 1:L
%         usersInCell = find(association==j)';
%         for s = 1:N
%             i = oldSchedule(j,s);
%             A = norm(U(:,j,s)'*H(:,:,i,j)*V(:,i))^2;
%             B = noise*norm(U(:,j,s))^2;
%             for n = 1:L
%                 for t = 1:N
%                     m = oldSchedule(n,t);
%                     B = B + norm(U(:,j,s)'*H(:,:,m,j)*V(:,m))^2;
%                 end
%             end
%             B = B - A;
%             
%             bestWeightedRate = weight(i)*log2(1+A/B);
%             
%             for i = usersInCell
%                 if sum(schedule(j,:)==i) > 0
%                     continue % this user already scheduled
%                 end
%                 A = norm(U(:,j,s)'*H(:,:,i,j)*V(:,i))^2;
%                 thisWeightedRate = weight(i)*log2(1+A/B);
%                 if thisWeightedRate > bestWeightedRate
%                     schedule(j,s) = i;
%                     bestWeightedRate = thisWeightedRate;
%                 end
%             end
%         end
%     end
% end