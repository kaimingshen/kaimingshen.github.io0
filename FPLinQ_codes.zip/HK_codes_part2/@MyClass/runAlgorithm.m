function [ schedule, V ] = runAlgorithm( obj, weight )

numIter = 30;%50;

switch obj.algorithm
    case 'Proposed'
        [ schedule, V ] = runProposed(obj, weight, numIter);
    case 'Direct'
        [ schedule, V ] = runDirect( obj, weight, numIter );
    case 'FP'
        [ schedule, V ] = runFP(obj, weight, numIter);
    case 'ITLinQP'
        [ schedule, V ] = runITLinQP( obj, weight, numIter );
 
    otherwise
        error('unknown algorithm')
end

end