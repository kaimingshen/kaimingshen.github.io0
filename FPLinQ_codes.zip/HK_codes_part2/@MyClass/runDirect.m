function [ schedule, V ] = runDirect( obj, weight, numIter )

K = obj.numUser;
M = obj.numTxAnte;
maxPower = obj.maxPower;
schedule = initScheduler(obj, weight);
V = nan(M,M,K);
for i = 1:K
    V(:,:,i) = ones(M,M,1)*sqrt(maxPower(i)/(M*M));
end

convere = nan(numIter,1);

for iter = 1:numIter
    [txRate, rxRate, rate] = computeInstRate(obj, schedule, V);
    converge(iter) = sum(sum(rate));
    
    V = runBeamforming( obj, weight, schedule, V );
%     schedule = directMatching( obj, weight, V );
end

% hold on; plot(converge,'r')

end

function [ schedule ] = directMatching( obj, weight, V )

intend = obj.intend;
L = obj.numBS;
K = obj.numUser;
noise = obj.noise;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
schedule = zeros(L,1);

utility = zeros(K,L);
for i = 1:K
    if isempty(intend{i})
        continue
    end
    for j = intend{i}
        B = eye(N)*noise;
        for m = 1:K
            if m==i
                continue
            end
            B = B + H(:,:,m,j)*V(:,:,m)*V(:,:,m)'*H(:,:,m,j)'; 
        end
        SINR = real(V(:,:,i)'*H(:,:,i,j)'*(B\(H(:,:,i,j)*V(:,:,i))));
        utility(i,j) = weight(i,j)*log2(det(eye(M)+SINR));
    end
end

if K>=L
    schedule = Hungarian(utility);   
    for j = 1:L
        i = schedule(j);
        if utility(i,j)<=0
            schedule(j) = 0;
        end
    end
else
    map = Hungarian(utility');
    for i = 1:K
        j = map(i);
        if utility(i,j)>0
            schedule(j) = i;
        end
    end
end

if sum(schedule)==0
    error('zero schedule')
end

end