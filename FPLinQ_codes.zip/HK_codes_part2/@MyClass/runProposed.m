function [ schedule, V ] = runProposed( obj, weight, numIter )

K = obj.numUser;
M = obj.numTxAnte;
maxPower = obj.maxPower;
schedule = initScheduler(obj, weight);
V = nan(M,M,K);
for i = 1:K
    V(:,:,i) = ones(M,M,1)*sqrt(maxPower(i)/(M*M));
end

converge = nan(numIter,1);

for iter = 1:numIter   
    [txRate, rxRate, rate] = computeInstRate(obj, schedule, V);
    converge(iter) = sum(sum(rate));
    
%     SINR = computeSINR(obj, schedule, V);
    gamma = updateGamma(obj, schedule, V);
    Y = updateY( obj, weight, schedule, V, gamma );
	[ schedule, V ] = updateScheduleAndV( obj, weight, gamma, Y, schedule );
    [ schedule ] = directMatching( obj, weight, V );
end

% figure; plot(converge)

end

function [ gamma ] = updateGamma(obj, schedule, V)

L = obj.numBS;
K = obj.numUser;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
noise = obj.noise;
gamma = zeros(M,M,K,L);
SINR = computeSINR(obj, schedule, V);

for j = 1:L
    B = noise*eye(N);
    for i = 1:K
        B = B + H(:,:,i,j)*V(:,:,i)*V(:,:,i)'*H(:,:,i,j)';
    end
    
    for i = 1:K
        INTF = B - H(:,:,i,j)*V(:,:,i)*V(:,:,i)'*H(:,:,i,j)';
        gamma(:,:,i,j) = V(:,:,i)'*H(:,:,i,j)'*(INTF\(H(:,:,i,j)*V(:,:,i)));
    end
end

gamma = real(gamma);

end

%%
function [ Y ] = updateY( obj, weight, schedule, V, gamma )

L = obj.numBS;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
Y = zeros(N,M,L);
noise = obj.noise;

for j = 1:L
    i = schedule(j);
    if i==0
        continue
    end
    A = sqrt(weight(i,j))*H(:,:,i,j)*V(:,:,i)*sqrtm(eye(M)+gamma(:,:,i,j));
    B = eye(N)*noise;
    for n = 1:L
        m = schedule(n);
        if m==0
            continue
        end
        B = B + H(:,:,m,j)*V(:,:,m)*V(:,:,m)'*H(:,:,m,j)';
    end
    Y(:,:,j) = B\A;
end

end

%%
function [ schedule, V ] = updateScheduleAndV( obj, weight, gamma, Y, schedule )

intend = obj.intend;
L = obj.numBS;
K = obj.numUser;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
maxPower = obj.maxPower;
noise = obj.noise;
V = zeros(M,M,K);
Z = zeros(M,M,K,L);

for i = 1:K
    B = zeros(M,M);
    for n = 1:L
        B = B + H(:,:,i,n)'*Y(:,:,n)*Y(:,:,n)'*H(:,:,i,n);
    end
    
    for j = intend{i}
        A = sqrt(weight(i,j))*H(:,:,i,j)'*Y(:,:,j)*sqrtm(eye(M)+gamma(:,:,i,j));
        tempZ = B\A;        
        if trace(tempZ*tempZ') <= maxPower(i)
            Z(:,:,i,j) = tempZ;
            continue
        end
        % bisection search on opt mu
        muLeft = 0;
        muRight = 1;
        while 1
            tempZ = (B+muRight*eye(M))\A;
            if trace(tempZ*tempZ') <= maxPower(i)
                break
            end
            muRight = muRight*10;
        end
        
%         count = 0;
        while 1
            mu = (muLeft+muRight)/2;
            tempZ = (B+mu*eye(M))\A;
            if abs(trace(tempZ*tempZ')-maxPower(i)) < noise
                Z(:,:,i,j) = tempZ;
                break
            end
%             if count==500 || abs(trace(tempZ*tempZ')-maxPower(i)) < maxPower(i)/1e2
%                 Z(:,:,i,j) = tempZ;
%                 break
%             end
%             count = count + 1;
            if trace(tempZ*tempZ') > maxPower(i)
                muLeft = mu;
            else
                muRight = mu;
            end
        end
    end
end

% matching
utility = zeros(K,L);
for i = 1:K
    for j = intend{i}
        utility(i,j) = weight(i,j)*log(det(eye(M)+gamma(:,:,i,j))) - weight(i,j)*trace(gamma(:,:,i,j))...
                + trace(2*sqrt(weight(i,j))*sqrtm(eye(M)+gamma(:,:,i,j))*Z(:,:,i,j)'*H(:,:,i,j)'*Y(:,:,j));
        for n = 1:L
            utility(i,j) = utility(i,j) - trace(Y(:,:,n)'*H(:,:,i,n)*Z(:,:,i,j)*Z(:,:,i,j)'*H(:,:,i,n)'*Y(:,:,n));
        end
    end
end

utility = max(0,real(utility));

% for j = 1:L
%     i = schedule(j);
%     if i~=0
%         V(:,:,i) = Z(:,:,i,j);
%     end
% end
% return

if K>=L
    schedule = Hungarian(utility);
    for j = 1:L
        i = schedule(j);
        V(:,:,i) = Z(:,:,i,j);
        %
        if utility(i,j)<=0
            schedule(j) = 0;
            V(:,:,i) = zeros(M,M);
        end
    end    
else
    map = Hungarian(utility');
    for i = 1:K
        j = map(i);
        schedule(j) = i;
        V(:,:,i) = Z(:,:,i,j);
        %
        if utility(i,j)<=0;
            schedule(j) = 0;
            V(:,:,i) = zeros(M,M);
        end
    end
end
% 
% if sum(schedule>0)<5
%     hold on
% end
% 
% if sum(V~=0)<5
%     hold on
% end
            
end

function [ schedule ] = directMatching( obj, weight, V )

intend = obj.intend;
L = obj.numBS;
K = obj.numUser;
noise = obj.noise;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
schedule = zeros(L,1);

utility = zeros(K,L);
for i = 1:K
    if isempty(intend{i})
        continue
    end
    for j = intend{i}
        B = eye(N)*noise;
        for m = 1:K
            if m==i
                continue
            end
            B = B + H(:,:,m,j)*V(:,:,m)*V(:,:,m)'*H(:,:,m,j)'; 
        end
        SINR = real(V(:,:,i)'*H(:,:,i,j)'*(B\(H(:,:,i,j)*V(:,:,i))));
        utility(i,j) = weight(i,j)*log(det(eye(M)+SINR));
    end
end
    
if K>=L
    schedule = Hungarian(utility);   
    %%
    for j = 1:L
        i = schedule(j);
        if utility(i,j)<=0
            schedule(j) = 0;
        end
    end
else
    map = Hungarian(utility');
    for i = 1:K
        j = map(i);
        if utility(i,j)>0
            schedule(j) = i;
        end
    end
end

% if sum(schedule>0)<5
%     hold on
% end

end