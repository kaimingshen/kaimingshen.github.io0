function [ txRate, rxRate, rate ] = computeInstRate(obj, schedule, V)

intend = obj.intend;
K = obj.numUser;
L = obj.numBS;
M = obj.numTxAnte;
BW = obj.bandwidth;

SINR = computeSINR(obj, schedule, V);

txRate = zeros(K,1);
rxRate = zeros(L,1);
rate = zeros(K,L);
for j = 1:L
    i = schedule(j);
    if i==0
        continue
    end
    
    if sum(intend{i}==j)==0
        error('unexpected scheduling')
    end
    
    txRate(i) = BW*log2(det(eye(M)+SINR(:,:,j)));
    rxRate(j) = txRate(i);
    rate(i,j) = txRate(i);
end

end