clc; clear;
ctime = datestr(now,30);
tseed = str2double(ctime((end-5):end));
rand('seed',tseed)
randn('seed',tseed)
rand()
randn()

%% consider uplink
numUser = 50; % transmitters
numBS = 20; % receivers
bandwidth = 10; % in MHz
noise = 10^((-184-30)/10)*bandwidth*1e6;
maxPower = ones(numUser,1)*10^((20-30)/10);
numTxAnte = 1; numRxAnte = 1;
numSlot = 300;%200;

[ H, G, intend ] = generateNetwork( numBS, numUser, numTxAnte, numRxAnte );

numAlg = 5;
algorithm = cell(numAlg,1);
algorithm{1} = 'Proposed';
algorithm{2} = 'Direct';
algorithm{3} = 'ITLinQP';
obj = cell(numAlg,1);
rate = cell(numAlg,1);
   
for alg = [1 2]
    obj{alg} = MyClass(bandwidth, numBS, numUser, noise, numSlot, numTxAnte,...
        numRxAnte, H, G, maxPower, algorithm{alg}, intend);
    rate{alg} = obj{alg}.computeAvgRate();
end

sum(rate{1})
sum(rate{2})

save(strrep(strrep(num2str(clock),' ',''),'.','_'), 'rate');
% 
% 
figure; hold on
[x, y] = ecdf(rate{1}); plot(y,x,'b')
[x, y] = ecdf(rate{2}); plot(y,x,'r')
% [x, y] = ecdf(rate{3}); plot(y,x,'g')
