function [ schedule, V ] = runMAX( obj, weight, numIter )

K = obj.numUser;
L = obj.numBS;
M = obj.numTxAnte;
G = obj.chnMagnitude;
maxPower = obj.maxPower;

schedule = zeros(L,1);
for j = 1:L
    user_cell = [];
    for i = 1:K
        [~,n] = max(G(i,:));
        if n==j
            user_cell = [user_cell,i];
        end
    end
    if ~isempty(user_cell)
        schedule(j) = user_cell(randi(numel(user_cell)));
    end
end

% initialize V
V = nan(M,M,K);
for i = 1:K
    V(:,:,i) = ones(M,M,1)*sqrt(maxPower(i)/(M*M));
end

SINR = computeSINR(obj, schedule, V);

for iter = 1:numIter
%     SINR = computeSINR(obj, schedule, V);
    Y = updateY( obj, weight, schedule, V, SINR );
    SINR = computeSINR(obj, schedule, V);
    V = updateScheduleAndV( obj, weight, SINR, Y, schedule );
end

end

%%
function [ Y ] = updateY( obj, weight, schedule, V, SINR )

L = obj.numBS;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
Y = zeros(N,M,L);
noise = obj.noise;

for j = 1:L
    i = schedule(j);
    if i==0
        continue
    end
    A = H(:,:,i,j)*V(:,:,i);
    B = eye(N)*noise;
    for n = 1:L
        m = schedule(n);
        if m==0
            continue
        end
        B = B + H(:,:,m,j)*V(:,:,m)*V(:,:,m)'*H(:,:,m,j)';
    end
    Y(:,:,j) = B\A;
end

end

%%
function [ V ] = updateScheduleAndV( obj, weight, SINR, Y, schedule )

L = obj.numBS;
K = obj.numUser;
M = obj.numTxAnte;
N = obj.numRxAnte;
H = obj.chn;
maxPower = obj.maxPower;
V = zeros(M,M,K);
Z = zeros(M,M,K,L);

for i = 1:K
    B = zeros(M,M);
    for n = 1:L
        m = schedule(n);
        if m==0
            continue
        end
        B = B + weight(m)*H(:,:,i,n)'*Y(:,:,n)*(eye(M)+SINR(:,:,n))*Y(:,:,n)'*H(:,:,i,n);
    end
    
    for j = 1:L
        if schedule(j)~=i
            continue
        end
        A = weight(i)*H(:,:,i,j)'*Y(:,:,j)*(eye(M)+SINR(:,:,j));
        tempZ = B\A;
        
        if trace(tempZ*tempZ') <= maxPower(i)
            Z(:,:,i,j) = tempZ;
            continue
        end
        
        % bisection search on opt mu
        muLeft = 0;
        muRight = 1;
        while 1
            tempZ = (B+muRight*eye(M))\A;
            if trace(tempZ*tempZ') <= maxPower(i)
                break
            end
            muRight = muRight*10;
        end
        
        while 1
            mu = (muLeft+muRight)/2;
            tempZ = (B+mu*eye(M))\A;
            if abs(trace(tempZ*tempZ')-maxPower(i)) < maxPower(i)/1e3
                Z(:,:,i,j) = tempZ;
                break
            end
            
            if trace(tempZ*tempZ') > maxPower(i)
                muLeft = mu;
            else
                muRight = mu;
            end
        end
    end
end

for j = 1:L
    i = schedule(j);
    if i==0
        continue
    end
    V(:,:,i) = Z(:,:,i,j);
end

end