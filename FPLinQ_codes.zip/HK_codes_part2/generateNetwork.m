function [ chn, G, intend ] = generateNetwork( L, K, M, N )

% ITU-1411

range = 200; % here and throughout, measured in meter
rxPosition = (rand(L,1) + 1i*rand(L,1))*range;
maxDist = 65;
minDist = 2;

txPosition = (rand(K,1) + 1i*rand(K,1))*range;

% rxPosition = nan(L,1);
% for i = 1:L
%     while(1)
%         rand_dir = randn() + randn()*1i;
%         dist = (minDist+(maxDist-minDist)*rand);
%         rxPosition(i) = dist*rand_dir/norm(rand_dir) + txPosition(i);
%         norm(rxPosition(i)-txPosition(i)) % print dist of each link
%         if real(rxPosition(i))>=0 && real(rxPosition(i))<=range ...
%             && imag(rxPosition(i))>=0 && imag(rxPosition(i))<=range
%             break
%         end
%     end
% end

% plot the topology
figure; 
hold on;
plot(real(txPosition), imag(txPosition),'ro');
plot(real(rxPosition), imag(rxPosition),'b^');
xlabel('meter'); ylabel('meter');

c = 3e8; % speed of light
freq = 2.4e9; % in Hz
wavelength = c/freq; % in meter
Rbp = 4*1.5^2/wavelength;
Lbp = abs(20*log10(wavelength^2/(8*pi*1.5^2)));

dist = nan(K,L);
PL = nan(K,L); % pathloss in dB
for i = 1:K
    for j = 1:L
        dist(i,j) = abs(txPosition(i)-rxPosition(j));
        if dist(i,j)<=Rbp
            PL(i,j) = Lbp + 6 + 20*log10(dist(i,j)/Rbp);
        else
            PL(i,j) = Lbp + 6 + 40*log10(dist(i,j)/Rbp);
        end
    end
end

PL = PL + randn(K,L)*10 - 2.5 + 7; % shadowing; ante gain; noie figure

G = 10.^(-PL/10); % chn magnitude gain
chn = nan(N,M,K,L); % chn coefficient

for i = 1:K
    for j = 1:L
        chn(:,:,i,j) = sqrt(G(i,j))*(randn([N,M,1,1])...
            +1i*randn([N,M,1,1]))/sqrt(2);
    end
end

intend = cell(K,1);
% maxInt = 30;
for i = 1:K
%     potential_BSs = find(dist(i,:)<=maxDist & dist(i,:)>=minDist);
% %     numInt = length(potential_BSs);
%     numInt = min(randi(maxInt), length(potential_BSs));
% %     numInt = min(3, length(potential_BSs));
%     if numInt==0
%         continue
%     end
%     shuffle = potential_BSs(randperm(length(potential_BSs)));
%     intend{i} = shuffle(1:numInt);
    [~,J] = sort(dist(i,:),'ascend');
%     intend{i} = J(randperm(3,2));
    intend{i} = randperm(L,2);
end

end