for iter = 1:30
    main
    pause(1)
end