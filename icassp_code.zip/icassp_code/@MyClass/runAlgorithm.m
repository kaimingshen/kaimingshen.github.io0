function [ schedule, U, V ] = runAlgorithm( obj, weight )

numIter = 50;

switch obj.algorithm
    case 'proposed'
        [ schedule, U, V ] = runProposed(obj, weight, numIter);
    case 'WMMSE'
        [ schedule, U, V ] = runWMMSE(obj, weight, numIter);
    case 'fixed'
        [ schedule, U, V ] = runFixed(obj, weight, numIter);
    otherwise
        error('unidentified algorithm')
end

end