function [ currentRate ] = computeCurrentRate(obj, schedule, U, V)

currentSINR = computeCurrentSINR(obj, schedule, U, V);
currentRate = obj.bandwidth*log2(1+currentSINR);

end